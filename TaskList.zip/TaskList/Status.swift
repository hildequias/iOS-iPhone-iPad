//
//  Status.swift
//  TaskList
//
//  Created by Mobile6 on 3/8/16.
//  Copyright © 2016 Pixonsoft. All rights reserved.
//

import Foundation
import CoreData

@objc(Status)
class Status: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
